'use strict';

var should = require('should'),
  request = require('supertest'),
  path = require('path'),
  mongoose = require('mongoose'),
  User = mongoose.model('User'),
  Evento = mongoose.model('Evento'),
  express = require(path.resolve('./config/lib/express'));

/**
 * Globals
 */
var app, agent, credentials, user, evento;

/**
 * Evento routes tests
 */
describe('Evento CRUD tests', function () {

  before(function (done) {
    // Get application
    app = express.init(mongoose);
    agent = request.agent(app);

    done();
  });

  beforeEach(function (done) {
    // Create user credentials
    credentials = {
      username: 'username',
      password: 'M3@n.jsI$Aw3$0m3'
    };

    // Create a new user
    user = new User({
      firstName: 'Full',
      lastName: 'Name',
      displayName: 'Full Name',
      email: 'test@test.com',
      username: credentials.username,
      password: credentials.password,
      provider: 'local'
    });

    // Save a user to the test db and create new evento
    user.save(function () {
      evento = {
        title: 'Evento Title',
        content: 'Evento Content'
      };

      done();
    });
  });

  it('should be able to save an evento if logged in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new evento
        agent.post('/api/eventos')
          .send(evento)
          .expect(200)
          .end(function (articleSaveErr, articleSaveRes) {
            // Handle evento save error
            if (articleSaveErr) {
              return done(articleSaveErr);
            }

            // Get a list of eventos
            agent.get('/api/eventos')
              .end(function (articlesGetErr, articlesGetRes) {
                // Handle evento save error
                if (articlesGetErr) {
                  return done(articlesGetErr);
                }

                // Get eventos list
                var eventos = articlesGetRes.body;

                // Set assertions
                (eventos[0].user._id).should.equal(userId);
                (eventos[0].title).should.match('Evento Title');

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should not be able to save an evento if not logged in', function (done) {
    agent.post('/api/eventos')
      .send(evento)
      .expect(403)
      .end(function (articleSaveErr, articleSaveRes) {
        // Call the assertion callback
        done(articleSaveErr);
      });
  });

  it('should not be able to save an evento if no title is provided', function (done) {
    // Invalidate title field
    evento.title = '';

    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new evento
        agent.post('/api/eventos')
          .send(evento)
          .expect(400)
          .end(function (articleSaveErr, articleSaveRes) {
            // Set message assertion
            (articleSaveRes.body.message).should.match('Title cannot be blank');

            // Handle evento save error
            done(articleSaveErr);
          });
      });
  });

  it('should be able to update an evento if signed in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new evento
        agent.post('/api/eventos')
          .send(evento)
          .expect(200)
          .end(function (articleSaveErr, articleSaveRes) {
            // Handle evento save error
            if (articleSaveErr) {
              return done(articleSaveErr);
            }

            // Update evento title
            evento.title = 'WHY YOU GOTTA BE SO MEAN?';

            // Update an existing evento
            agent.put('/api/eventos/' + articleSaveRes.body._id)
              .send(evento)
              .expect(200)
              .end(function (articleUpdateErr, articleUpdateRes) {
                // Handle evento update error
                if (articleUpdateErr) {
                  return done(articleUpdateErr);
                }

                // Set assertions
                (articleUpdateRes.body._id).should.equal(articleSaveRes.body._id);
                (articleUpdateRes.body.title).should.match('WHY YOU GOTTA BE SO MEAN?');

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should be able to get a list of eventos if not signed in', function (done) {
    // Create new evento model instance
    var articleObj = new Evento(evento);

    // Save the evento
    articleObj.save(function () {
      // Request eventos
      request(app).get('/api/eventos')
        .end(function (req, res) {
          // Set assertion
          res.body.should.be.instanceof(Array).and.have.lengthOf(1);

          // Call the assertion callback
          done();
        });

    });
  });

  it('should be able to get a single evento if not signed in', function (done) {
    // Create new evento model instance
    var articleObj = new Evento(evento);

    // Save the evento
    articleObj.save(function () {
      request(app).get('/api/eventos/' + articleObj._id)
        .end(function (req, res) {
          // Set assertion
          res.body.should.be.instanceof(Object).and.have.property('title', evento.title);

          // Call the assertion callback
          done();
        });
    });
  });

  it('should return proper error for single evento with an invalid Id, if not signed in', function (done) {
    // test is not a valid mongoose Id
    request(app).get('/api/eventos/test')
      .end(function (req, res) {
        // Set assertion
        res.body.should.be.instanceof(Object).and.have.property('message', 'Evento is invalid');

        // Call the assertion callback
        done();
      });
  });

  it('should return proper error for single evento which doesnt exist, if not signed in', function (done) {
    // This is a valid mongoose Id but a non-existent evento
    request(app).get('/api/eventos/559e9cd815f80b4c256a8f41')
      .end(function (req, res) {
        // Set assertion
        res.body.should.be.instanceof(Object).and.have.property('message', 'No evento with that identifier has been found');

        // Call the assertion callback
        done();
      });
  });

  it('should be able to delete an evento if signed in', function (done) {
    agent.post('/api/auth/signin')
      .send(credentials)
      .expect(200)
      .end(function (signinErr, signinRes) {
        // Handle signin error
        if (signinErr) {
          return done(signinErr);
        }

        // Get the userId
        var userId = user.id;

        // Save a new evento
        agent.post('/api/eventos')
          .send(evento)
          .expect(200)
          .end(function (articleSaveErr, articleSaveRes) {
            // Handle evento save error
            if (articleSaveErr) {
              return done(articleSaveErr);
            }

            // Delete an existing evento
            agent.delete('/api/eventos/' + articleSaveRes.body._id)
              .send(evento)
              .expect(200)
              .end(function (articleDeleteErr, articleDeleteRes) {
                // Handle evento error error
                if (articleDeleteErr) {
                  return done(articleDeleteErr);
                }

                // Set assertions
                (articleDeleteRes.body._id).should.equal(articleSaveRes.body._id);

                // Call the assertion callback
                done();
              });
          });
      });
  });

  it('should not be able to delete an evento if not signed in', function (done) {
    // Set evento user
    evento.user = user;

    // Create new evento model instance
    var articleObj = new Evento(evento);

    // Save the evento
    articleObj.save(function () {
      // Try deleting evento
      request(app).delete('/api/eventos/' + articleObj._id)
        .expect(403)
        .end(function (articleDeleteErr, articleDeleteRes) {
          // Set message assertion
          (articleDeleteRes.body.message).should.match('User is not authorized');

          // Handle evento error error
          done(articleDeleteErr);
        });

    });
  });

  afterEach(function (done) {
    User.remove().exec(function () {
      Evento.remove().exec(done);
    });
  });
});
