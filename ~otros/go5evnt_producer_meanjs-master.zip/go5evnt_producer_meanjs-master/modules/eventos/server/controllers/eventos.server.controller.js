'use strict';

/**
 * Module dependencies.
 */
var path = require('path'),
  _ = require('lodash'),
  mongoose = require('mongoose'),
  Evento = mongoose.model('Evento'),
  kafka = require('kafka-node'),
  Producer = kafka.Producer,
  errorHandler = require(path.resolve('./modules/core/server/controllers/errors.server.controller'));


var notifyEvent = function( msg ) {

  var client = new kafka.Client('192.168.90.30:2181');
  var producer = new Producer(client);

  var payloads = [
      //{ topic: 'my-topic-test', messages: [msg], partition: 0 },
      { topic: 'my-topic-test', messages: JSON.stringify(msg), partition: 0 },
  ];
  console.log("notifyEvent.req=");
  console.log(msg);

  producer.on('ready', function() {
    producer.send(payloads, function(err, data){
		    console.log('notifyEventOk_Sending');
        console.log(data);
     });
  });
  producer.on('error', function(error) {
    console.log('notifyEventError', error);
  });

};

/**
 * Create a evento
 */
exports.create = function (req, res) {
  var evento = new Evento(req.body);
  evento.user = req.user;

  evento.save(function (err) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      // TODO: concatenar promises?
      console.log("+evento.create");
      console.log(evento);

      console.log("+evento.create.sendMsg");
      notifyEvent({
        'eventType':'evento.create',
        'eventDate': new Date(),
        'payload': evento
      });

      res.json(evento);
    }
  });
};

/**
 * Show the current evento
 */
exports.read = function (req, res) {
  res.json(req.evento);
};

/**
 * Update a evento
 */
exports.update = function (req, res) {
  var evento = req.evento;

  evento = _.extend(evento, req.body);
  // evento.title = req.body.title;
  // evento.content = req.body.content;

  evento.save(function (err) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(evento);
    }
  });
};

/**
 * Delete an evento
 */
exports.delete = function (req, res) {
  var evento = req.evento;

  evento.remove(function (err) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(evento);
    }
  });
};

/**
 * List of Eventos
 */
exports.list = function (req, res) {
  Evento
  .find()
  .sort('-created')
  .populate('user', 'displayName')
  .exec(function (err, eventos) {
    if (err) {
      return res.status(400).send({
        message: errorHandler.getErrorMessage(err)
      });
    } else {
      res.json(eventos);
    }
  });
};

/**
 * Evento middleware
 */
exports.eventoByID = function (req, res, next, id) {

  if (!mongoose.Types.ObjectId.isValid(id)) {
    return res.status(400).send({
      message: 'Evento is invalid'
    });
  }

  Evento.findById(id).populate('user', 'displayName').exec(function (err, evento) {
    if (err) {
      return next(err);
    } else if (!evento) {
      return res.status(404).send({
        message: 'No evento with that identifier has been found'
      });
    }
    req.evento = evento;
    next();
  });
};
