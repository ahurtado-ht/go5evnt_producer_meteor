'use strict';

// Setting up route
angular.module('eventos').config(['$stateProvider',
  function ($stateProvider) {
    // Eventos state routing
    $stateProvider
      .state('eventos', {
        abstract: true,
        url: '/eventos',
        template: '<ui-view/>'
      })
      .state('eventos.list', {
        url: '',
        templateUrl: 'modules/eventos/client/views/list-eventos.client.view.html'
      })
      .state('eventos.create', {
        url: '/create',
        templateUrl: 'modules/eventos/client/views/create-evento.client.view.html',
        data: {
          roles: ['user', 'admin']
        }
      })
      .state('eventos.view', {
        url: '/:eventoId',
        templateUrl: 'modules/eventos/client/views/view-evento.client.view.html'
      })
      .state('eventos.edit', {
        url: '/:eventoId/edit',
        templateUrl: 'modules/eventos/client/views/edit-evento.client.view.html',
        data: {
          roles: ['user', 'admin']
        }
      });
  }
]);
