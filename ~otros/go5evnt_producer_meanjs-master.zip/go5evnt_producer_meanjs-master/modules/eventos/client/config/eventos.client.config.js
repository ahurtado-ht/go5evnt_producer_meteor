'use strict';

// Configuring the Eventos module
angular.module('eventos').run(['Menus',
  function (Menus) {
    // Add the eventos dropdown item
    Menus.addMenuItem('topbar', {
      title: 'Administración',
      state: 'administracion',
      type: 'dropdown',
      roles: ['user']
    });

    // Add the dropdown list item
    Menus.addSubMenuItem('topbar', 'administracion', {
      title: 'Eventos',
      state: 'eventos.list'
    });

    // Add the dropdown create item
    /*
    Menus.addSubMenuItem('topbar', 'eventos', {
      title: 'Create Eventos',
      state: 'eventos.create',
      roles: ['user']
    });
    */
  }
]);
