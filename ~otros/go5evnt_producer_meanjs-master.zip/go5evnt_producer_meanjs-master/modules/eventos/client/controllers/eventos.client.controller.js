'use strict';

// Eventos controller
angular.module('eventos').controller('EventosController', ['$scope', '$stateParams', '$location', 'Authentication', 'Eventos','EventosForm',
  function ($scope, $stateParams, $location, Authentication, Eventos, EventosForm) {
    $scope.authentication = Authentication;

    $scope.evento = {};
    //$scope.tableParams = TableSettings.getParams(Ciudades);

    $scope.setFormFields = function(disabled) {
      $scope.formFields = EventosForm.getFormFields(disabled);
		};


    // Create new Evento
    $scope.create = function (isValid) {
      $scope.error = null;

      if (!isValid) {
        $scope.$broadcast('show-errors-check-validity', 'usuarioForm');

        return false;
      }

      // Create new Evento object
      var evento = new Eventos($scope.evento);

      // Redirect after save
      evento.$save(function (response) {
        $location.path('eventos'); // + '/' + response._id);

        // Clear form fields
        // $scope.title = '';
        // $scope.content = '';
      }, function (errorResponse) {
        $scope.error = errorResponse.data.message;
      });
    };

    // Remove existing Evento
    $scope.remove = function (evento) {
      if (evento) {

        evento = Eventos.get({eventoId:evento._id}, function(){
          evento.$remove();
					// $scope.tableParams.reload();
        });
        /*
        evento.$remove();

        for (var i in $scope.eventos) {
          if ($scope.eventos[i] === evento) {
            $scope.eventos.splice(i, 1);
          }
        }
        */

      } else {
        $scope.evento.$remove(function () {
          $location.path('eventos');
        });
      }
    };

    // Update existing Evento
    $scope.update = function (isValid) {
      $scope.error = null;

      if (!isValid) {
        $scope.$broadcast('show-errors-check-validity', 'usuarioForm');

        return false;
      }

      var evento = $scope.evento;

      evento.$update(function () {
        $location.path('eventos'); // + "/' + evento._id);
      }, function (errorResponse) {
        $scope.error = errorResponse.data.message;
      });
    };

    // Find a list of Eventos
    $scope.find = function () {
      $scope.eventos = Eventos.query();
    };

    // Find existing Evento
    $scope.findOne = function () {
      $scope.evento = Eventos.get({
        eventoId: $stateParams.eventoId
      });
      $scope.setFormFields(false);
    };
  }
]);
