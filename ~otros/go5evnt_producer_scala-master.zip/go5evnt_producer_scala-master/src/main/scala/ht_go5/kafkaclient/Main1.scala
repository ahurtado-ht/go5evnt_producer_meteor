package ht_go5.kafkaclient

import java.util.Properties

import kafka.producer.KeyedMessage
import kafka.producer.KafkaProducer
import kafka.producer.ProducerConfig
import kafka.producer.Producer

object Main1 {
  def main(args: Array[String]): Unit = {
    val props = new Properties()
    props.put("metadata.broker.list", "192.168.1.40:9092" )
    props.put("client.id", "KafkaProducer")
    props.put("serializer.class",     "kafka.serializer.StringEncoder")
    props.put("key.serializer.class", "kafka.serializer.StringEncoder" )
    props.put("request.required.acks", "1")    

    val config = new ProducerConfig(props)
    
    val testTopic = "my-topic-test"
    val producer = new Producer[AnyRef, AnyRef](config)
    try {
      producer.send(new KeyedMessage("my-topic-test", "sss","hello kafka (scala Main3)" ))
    } catch {
        case e: Exception => e.printStackTrace
    }  
  
  
  }
  
}
