scaffold
instalar activator 1.3.7 (typesafe.com)

adicionar a etc/hosts
	192.168.1.40	gofive.mispesos


activator new 
 > tipo: minimal-scala
 > nombre: go5evnt_producer_scala

agregar  to project/plugins.sbt (acorde a https://www.playframework.com/documentation/2.4.x/IDE)
  addSbtPlugin("com.typesafe.sbteclipse" % "sbteclipse-plugin" % "4.0.0")
ejecutar 
  activator eclipse  

activator update #actualizar dependencias
activator run   #ejecutar